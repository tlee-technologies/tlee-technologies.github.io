INSERT INTO categories (name) VALUES ('Hot Drinks');
INSERT INTO categories (name) VALUES ('Cold Drinks');